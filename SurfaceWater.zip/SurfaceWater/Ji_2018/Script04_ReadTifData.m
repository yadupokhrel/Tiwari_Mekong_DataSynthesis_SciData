% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Mean Surface Water data

clear all; clc;

f1=dir('../Final_Output/2016_*.tif');
daysNLY=[0;31;59;90;120;151;181;212;243;273;304;334;365];
daysLY=[0;31;60;91;121;152;182;213;244;274;305;335;366];

days=daysLY;

% 61-Water; 62-Frozen water; 0-Land 
H=NaN(4470,2640,12); % Predefine H
for i=1:size(days,1)-1
    
    disp(i)
    
    f2=f1(days(i)+1:days(i+1),:);
    
    C=NaN(4470,2640,size(f2,1)); % Predefine C
    for j=1:size(f2,1)
        
        f3=f2(j).name;
        B=imread(['../Final_Output/',f3]);
        C(:,:,j)=double(B);
    end
    G=NaN(4470,2640); % Predefine G
    for k=1:size(C,1)
        D=squeeze(C(k,:,:));
        
        for m=1:size(D,1)
            E=D(m,:)';
            
            fd1=find(E==-128);
            fd2=find(E==0);
            fd3=find(E==61 | E==62);
            
            F=mean(E,1);
            
            if F==-128
                G(k,m)=NaN;
            else
                w=size(fd3,1)/size(E,1);
                G(k,m)=w;
            end
                
        end
    end
    
    H(:,:,i)=G;
    
end

I=sum(H,3);

writematrix(round(I,2), '2016.txt','Delimiter', 'tab')
imagesc(I); colorbar; colormap(flipud(hot))
