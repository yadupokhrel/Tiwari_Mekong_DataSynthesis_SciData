% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University
%% Extract ET data
clear all; clc;

ncdisp('../3.6/v3.6b/daily/E_2003_GLEAM_v3.6b.nc');

lon=ncread('../3.6/v3.6b/daily/E_2003_GLEAM_v3.6b.nc', 'lon');
lat=ncread('../3.6/v3.6b/daily/E_2003_GLEAM_v3.6b.nc', 'lat');

time=ncread('../3.6/v3.6b/daily/E_2003_GLEAM_v3.6b.nc', 'time');

lonlat=dlmread('../lonlat_mekong.txt');

for y=2003:2021
    mkdir(['../3.6_Extracted/Daily/GLEAM_3.6b/',num2str(y)])
    
    Data=ncread(['../3.6/v3.6b/daily/E_',num2str(y),'_GLEAM_v3.6b.nc'], 'E');
    
    for i=1:size(lon,1)
        for j=1:size(lat,1)
            
            disp([i j])
            ll=[lon(i), lat(j)];
            
            fd=find(round(lonlat(:,1),3)==round(ll(1,1),3) & round(lonlat(:,2),3)==round(ll(1,2),3));
            
            if isempty(fd)
                continue;
            else
                D=squeeze(Data(i,j,:));
                
                dlmwrite(['../3.6_Extracted/Daily/GLEAM_3.6b/',num2str(y),'/data_',num2str(lat(j)),'_',num2str(lon(i))], D, ' ')
            end
        end
    end
end

%% Combine ET data

clear all; clc;
lonlat=dlmread('../lonlat_mekong.txt');

TS1=dlmread('../TS_1920_2023');
TS=TS1(TS1(:,1)>=2003 & TS1(:,1)<=2021,:);

for i=1:size(lonlat,1)
    disp(i)
    D2=[];
    for y=2003:2021
        D1=dlmread(['../3.6_Extracted/Daily/GLEAM_3.6b/',num2str(y),'/data_',num2str(lonlat(i,2)),'_',num2str(lonlat(i))]);
        D2=[D2; D1];
    end
    D2(D2<0)=0;
    D3(:,i)=D2;
end

D4=[lonlat'; round(D3,2)];
D5=[[[NaN, NaN, NaN; NaN NaN NaN]; TS], D4];
writematrix(D5, '../Results/GLEAM_ET_v3.6b_Daily_2003_2021.txt', 'Delimiter', 'tab')


