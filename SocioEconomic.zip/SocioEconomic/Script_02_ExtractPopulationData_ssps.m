% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Extract projected population data
clear all; clc;

for s=1:5
    FinalData=[]; FData=[];
    for d=2010:10:2100
        ncdisp(['..\Population\Projected\nc\ssp',num2str(s),'_',num2str(d),'.nc'])
        lon=ncread(['..\Population\Projected\nc\ssp',num2str(s),'_',num2str(d),'.nc'], 'lon');
        lat=ncread(['..\Population\Projected\nc\ssp',num2str(s),'_',num2str(d),'.nc'], 'lat');

        lonlon=repmat(lon', size(lat,1),1);
        latlat=repmat(lat, 1, size(lon,1));

        lonlat=[reshape(lonlon, size(lonlon,1)*size(lonlon,2),1), reshape(latlat, size(lonlon,1)*size(lonlon,2),1)];

        % lonlat=lonlat(lonlat(:,1)>90 & lonlat(:,1)<110 & lonlat(:,2)>5 & lonlat(:,2)<35,:);

        DD=ncread(['..\Population\Projected\nc\ssp',num2str(s),'_',num2str(d),'.nc'], ['ssp',num2str(s),'_',num2str(d)]);
        DD=double(DD);

        n=1; Data=[];
        for i=1:size(lon)
            for j=1:size(lat,1)

                ll=[lon(i), lat(j)];

                if ll(1,1) >93.9 && ll(1,1)<108.7 && ll(1,2)>8.6 && ll(1,2)< 33.9
                    Data(n,:)=[ll, DD(i,j)];
                    n=n+1;
                else
                    continue;
                end

            end
        end
        FData(:,(d-2000)/10)=Data(:,end);

    end

    FinalData=[Data(:,1:2), FData];

    writematrix(FinalData, ['..\Population\Projected\Extracted\ssp',num2str(s),'_POP.txt'], 'Delimiter','tab')

end



