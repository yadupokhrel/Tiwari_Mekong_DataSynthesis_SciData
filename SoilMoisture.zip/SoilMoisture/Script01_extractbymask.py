# Python Script, January 20, 2023
# Amar Deep Tiwari (tiwaria6@msu.edu)
# Research Associate, Michigan State University

## Extract soil moisture data for Mekong
import os, numpy as np, arcpy
from arcpy import env
from arcpy.sa import *

arcpy.CheckOutExtension("Spatial")
arcpy.env.pyramid = "NONE"

arcpy.env.workspace = r'C:\Users\tiwaria6\OneDrive - Michigan State University\Work\MekongData\OtherDatasets\Shapefile_utm'
shapename= arcpy.ListFeatureClasses('*.shp') 
##in_raster = r'\1992.tif' 
arcpy.env.workspace = r'C:\Users\tiwaria6\OneDrive - Michigan State University\Work\smap_1km\Download\2021'
fl_name1= arcpy.ListRasters('*.tif')

for j in shapename:
    for i in fl_name1:
        print(i)
        inraster=r'C:\Users\tiwaria6\OneDrive - Michigan State University\Work\smap_1km\Download\2021'+'\\'+i
        shp=r'C:\Users\tiwaria6\OneDrive - Michigan State University\Work\MekongData\OtherDatasets\Shapefile_utm'+'\\'+j
        outraster=r'C:\Users\tiwaria6\OneDrive - Michigan State University\Work\smap_1km\Download\subsets\2021'+'\\'+i
        out = ExtractByMask(inraster, shp)
        out.save(outraster)
