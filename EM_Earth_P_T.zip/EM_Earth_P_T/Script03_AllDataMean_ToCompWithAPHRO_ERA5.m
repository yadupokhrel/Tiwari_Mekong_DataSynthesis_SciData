% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% TempMean

clear all; clc;
TS1=dlmread('TS_1950_2020.txt');
TS=TS1(TS1(:,1)>=1971 & TS1(:,1)<=2000,:);
lonlat=dlmread('corresp_lonlat_mekong_10km');
models={'001.nc';'002.nc';'003.nc';'004.nc';'005.nc';'006.nc';'007.nc';'008.nc';'009.nc';'010.nc';'011.nc';'012.nc';...
    '013.nc';'014.nc';'015.nc';'016.nc';'017.nc';'018.nc';'019.nc';'020.nc';'021.nc';'022.nc';'023.nc';'024.nc';'025.nc'};

parfor m=1:25

    disp(m)
    AT=dlmread(['..\Temperature\Timeseries\All\data_',char(models(m)),'.txt']);

    ATT(:,m)=mean(AT(7671:18628),1);

end

dlmwrite('..\Analysis\MeanTempData_v2.txt', [lonlat, mean(ATT,2)], ' ')

%% PrecipMean

clear all; clc;
TS1=dlmread('TS_1950_2020.txt');
TS=TS1(TS1(:,1)>=1971 & TS1(:,1)<=2000,:);
lonlat=dlmread('corresp_lonlat_mekong_10km');
models={'001.nc';'002.nc';'003.nc';'004.nc';'005.nc';'006.nc';'007.nc';'008.nc';'009.nc';'010.nc';'011.nc';'012.nc';...
    '013.nc';'014.nc';'015.nc';'016.nc';'017.nc';'018.nc';'019.nc';'020.nc';'021.nc';'022.nc';'023.nc';'024.nc';'025.nc'};


parfor m=1:25
    
    disp(m)
    AT=dlmread(['D:\MSU_Work\EM_Earth\Precipitation\Timeseris\All\data_',char(models(m)),'.txt']);
    AT1=AT(7671:18628,:);
    
    %     for i=1:size(AT1,2)
    %         AT2=[TS, AT1(:,i)];
    %         AT3=[];
    %         for y=1971:2000
    %             fd=find(AT2(:,1)==y);
    %             AT3(y-1970,1)=sum(AT2(fd,end));
    %         end
    %         AT4(i,:)=mean(AT3,1);
    %     end
    ATT(:,m)=sum(AT1,1)/30;
    
end

dlmwrite('..\Analysis\MeanPrecipData_v2.txt', [lonlat, mean(ATT,2)], ' ')