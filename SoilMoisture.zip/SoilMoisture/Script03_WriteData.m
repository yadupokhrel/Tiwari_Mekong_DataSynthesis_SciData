% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Write soil moisture data
clear all; clc;

load ../Extracted/soilmoisture_2016.mat
load ../Extracted/soilmoisture_2017.mat
load ../Extracted/soilmoisture_2018.mat
load ../Extracted/soilmoisture_2019.mat
load ../Extracted/soilmoisture_2020.mat
load ../Extracted/soilmoisture_2021.mat


A1=nanmean(soilmoisture_2016,3);
A2=nanmean(soilmoisture_2017,3);
A3=nanmean(soilmoisture_2018,3);
A4=nanmean(soilmoisture_2019,3);
A5=nanmean(soilmoisture_2020,3);
A6=nanmean(soilmoisture_2021,3);

A=[];
A(:,:,1)=A1;
A(:,:,2)=A2;
A(:,:,3)=A3;
A(:,:,4)=A4;
A(:,:,5)=A5;
A(:,:,6)=A6;

B=nanmean(soilmoisture_2018,3);
imshow(B(:,:)); colormap(jet); colorbar
writematrix('mean_soilmoisture.txt', B, 'Delimiter', 'tab')
% lon=ncread('smap_sm_1km_ds_2018001.nc', 'x');
% lat=ncread('smap_sm_1km_ds_2018001.nc', 'y');