% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% GDP projections percentage change
clear all; clc;

GridsC={'Cambodia'; 'China'; 'Laos'; 'Myanmar'; 'Thailand'; 'Vietnam'};

base=readmatrix('..\GDP\GDP_LitPopBase_025d_s\Extracted\GDP2005.txt');

for i=1:size(GridsC,1)
    PercChange=[];
    for k=1:5

        ssp=readmatrix(['..\GDP\GDP_LitPopBase_025d_s\Extracted\ssp',num2str(k),'_GDP.txt']);

        lonlat=readmatrix(['Grids_25km\',char(GridsC(i)),'Grids.txt']);

        Data=NaN(size(lonlat,1), 9);
        for j=1:size(lonlat,1)

            fd=find(ssp(:,1)==lonlat(j,1) & ssp(:,2)==lonlat(j,2));

            Data(j,:)=[base(fd,end), ssp(fd,3:end)];

        end

        MeanP=mean(Data,1);
        PercChange(:,k)=(MeanP(1, 2:end)-MeanP(1,1))*100/MeanP(1,1);
    end
    
    dlmwrite(['..\Results\GDPChange_',char(GridsC(i)),'.txt'], [[2030:10:2100]', PercChange], ' ')
    subplot(3,2,i); plot([2030:10:2100]', PercChange); title([char(GridsC(i))]); legend('ssp1', 'ssp2', 'ssp3', 'ssp4', 'ssp5')
end


