% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University
%% Extract APHRODITE temperature data
clear all; clc;

for y=1961:2015
    mkdir(['../APHRO_V1808_TEMP_MA_025deg/Extracted/',num2str(y)])
    
    ncdisp(['../APHRO_V1808_TEMP_MA_025deg/RAW/APHRO_MA_TAVE_025deg_V1808.',num2str(y),'.nc'])
    
    lon=ncread(['../APHRO_V1808_TEMP_MA_025deg/RAW/APHRO_MA_TAVE_025deg_V1808.',num2str(y),'.nc'], 'lon');
    lat=ncread(['../APHRO_V1808_TEMP_MA_025deg/RAW/APHRO_MA_TAVE_025deg_V1808.',num2str(y),'.nc'], 'lat');
    
    RLL=dlmread('lonlat_mekong_25km.txt');
    
    
    P=ncread(['../APHRO_V1808_TEMP_MA_025deg/RAW/APHRO_MA_TAVE_025deg_V1808.',num2str(y),'.nc'], 'tave');
    
    for i=1:size(lon,1)
        for j=1:size(lat,1)
            
            disp([y i j])
            lonlat=[lon(i,1), lat(j,1)];
            
            lonlat=double(lonlat);
            
            fd=find(RLL(:,1)==lonlat(1,1) & RLL(:,2)==lonlat(1,2));
            
            if isempty(fd)
                continue;
            else
                D=squeeze(P(i,j,:));
                E=round(D,2);
                
                dlmwrite(['../APHRO_V1808_TEMP_MA_025deg/Extracted/',num2str(y),'/data_',num2str(lat(j,1)),'_',num2str(lon(i,1))], E, ' ')
            end
        end
        
    end
    
end

%% Combine all data
LOLA=dlmread('lonlat_mekong_25km.txt');

for ii=1:size(LOLA,1)
    
    BB=[];
    for yy=1961:2015
        AA=dlmread(['../APHRO_V1808_TEMP_MA_025deg/Extracted/',num2str(yy),'/data_',num2str(LOLA(ii,2)),'_',num2str(LOLA(ii,1))]);
        BB=[BB; AA];
    end
    dlmwrite(['../APHRO_V1808_TEMP_MA_025deg/Extracted/1961_2015/data_',num2str(LOLA(ii,2)),'_',num2str(LOLA(ii,1))], BB, ' ');
end