% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Sediment data analysis
clear all; clc;

stations={'LA_011201_Luang_Prabang';'LA_013401_Savannakhet';'LA_013901_Pakse';'LA_014101_Ban_Mouang';...
    'LA_120102_Ban_Pak_Bak_(downstream)';'TH_010501_Chiang_Saen';'TH_010601_Sop_Kok';'TH_010801_Chiang_Khong';...
    'TH_011903_Chiang_Khan';'TH_011904_Pa_Mong_Dam_Site';'TH_012001_Nong_Khai';'TH_013101_Nakhon_Phanom';'TH_013402_Mukdahan';...
    'TH_013801_Khong_Chiam';'TH_051001_Dam_Site';'TH_370104_Yasothom';'TH_380111_Pak_Mun';'TH_380134_Rasi_Salai'};

A=importdata('..\Mekong_MRCS_Obs\Sediment\note_sediment.txt');

for i=1:size(stations)
    
    B=dlmread(['..\Mekong_MRCS_Obs\Sediment\TXT\',char(stations(i)),'.txt']);
    C=unique(B(:,1));
    
    D(i,:)=size(C,1);
end

lonlat=A.data;

shp=shaperead('..\Watershed_Outline\3sec_24000x32400_basinmask2.shp');

Mekong=[];
for i=1:size(shp,1)
    B=[shp(i).X; shp(i).Y]';
    Mekong=[Mekong; B];
end

load sequentialcolor.mat
subplot(1,2,1); scatter(lonlat(:,1), lonlat(:,2), 100); hold on
scatter(Mekong(:,1), Mekong(:,2), 1)
scatter(lonlat(:,1), lonlat(:,2), 100, D, 'filled'); colormap(sequentialcolor); colorbar; title({'Sediment concentration','(data available in years)'}); caxis([0 48])

subplot(1,2,2); bar(D); ylabel({'Sediment concentration','(data available in years)'}); xlabel('Station number')