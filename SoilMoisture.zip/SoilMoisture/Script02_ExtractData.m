% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Extract soil moisture data
clear all; clc;

files=dir('..\Download\subsets\2021\*.tif');  % Change years from 2016 to 2021

for i=1:size(files,1)
    disp(i)
    f=files(i).name;
    [A,R]= readgeoraster(['..\Download\subsets\2021\',f]);
    
%     B=A(2500:6300, 26000:28000,1);
    Band1=A(:,:,1); Band2=A(:,:,2);
    
    B4=NaN(size(Band1,1), size(Band1,2));
    for j=1:size(Band1,2)
        B1=Band1(:,j);
        B2=Band2(:,j);
        
        B3=max(B1,B2);
        
        B3(B3<0,1)=NaN;
        
        B4(:,j)=B3;
    end
    
    B5(:,:,i)=B4;
    
    
%     subplot(1,3,1); imshow(Band1); colormap(jet); colorbar
%     subplot(1,3,2); imshow(Band2); colormap(jet); colorbar
%     subplot(1,3,3); 
%     imshow(B6(:,:)); colormap(jet); colorbar
%     drawnow; pause(2)
    
end

B6=nanmean(B5,3);
soilmoisture_2021=B5;               % Change years from 2016 to 2021
clearvars -except soilmoisture_2021
