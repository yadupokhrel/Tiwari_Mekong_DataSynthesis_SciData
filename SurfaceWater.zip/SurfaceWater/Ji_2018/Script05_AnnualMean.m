% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Annual mean

clear all; clc;


for y=2001:2016
    disp(y)
    
    A=dlmread(['../Results/AnnualMean/',num2str(y),'.txt']);
    B(:,:,y-2000)=A;
    
end

C=nanmean(B,3);
imagesc(C); colorbar; colormap(flipud(hot))