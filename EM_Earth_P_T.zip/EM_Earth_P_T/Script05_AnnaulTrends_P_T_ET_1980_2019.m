% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Trends
clear all; clc;

P=dlmread('../Analysis/MeanAnnual/annual_precip_1980_2019.txt');
T=dlmread('../Analysis/MeanAnnual/annual_temp_1980_2019.txt');

ET=dlmread('../../ET/Results/year_mean_annual_ET_36a_v2.txt');


P_T_ET_PmET=[P, T(:,end), ET(1:end-2,2), P(:,2)-ET(1:end-2,2)];
ZZ=[P_T_ET_PmET(:,1), zscore(P_T_ET_PmET(:,2:end))];

dlmwrite('../Analysis/MeanAnnual/P_T_ET_PmET.txt', P_T_ET_PmET, ' ')
dlmwrite('../Analysis/MeanAnnual/zscore_P_T_ET_PmET.txt', ZZ, ' ')

for i=1:4
    datain=P_T_ET_PmET(:,[1 i+1]);
    [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 1)
    
    SENPLOT(:,i)=senplot(:,end);
end

dlmwrite('../Analysis/MeanAnnual/senplot_P_T_ET_PmET.txt', [[1980:2019]', SENPLOT], ' ')