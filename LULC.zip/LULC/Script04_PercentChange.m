% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Percentage change
clear all; clc;

ncdisp('..\Test\Final_2020-1992.nc');
flag_values=importdata('..\Subset\nc\flag_values.txt');
flag_meanings=importdata('..\Subset\nc\flag_meanings.txt');

Classes=NaN(29,38);


Aa1=ncread('..\Test\Final_1992.nc', 'Band1')';
Aa2=ncread('..\Test\Final_2020.nc', 'Band1')';

for k=1:size(Aa1,2)
    A1(:,k)=flip(Aa1(:,k));
    A2(:,k)=flip(Aa2(:,k));
end


E=NaN(size(A1,1), size(A1,2));
for i=1:size(A1,1)
    
    
    B1=A1(i,:);
    B2=A2(i,:);
    
    TP=size(B2(:,B2==0 | B2==1000 | B2== 5000),2);
    
    D=NaN(1,5370);
    for j=1:size(B1,2)
        
        C1=B1(1,j);
        C2=B2(1,j);
        
        if C1==0 && C2==0
            D(1,j)=-9999;
        elseif (C1==0 || C1==5000) && C2==1000
            D(1,j)=1;
        elseif (C1==0 || C1==1000) && C2==5000
            D(1,j)=2;
        else
            D(1,j)=-9999;
        end
        
    end
    E(i,:)=D;
    
    CropPer(i,:)=size(D(:,D==1),2)/TP;
    TreePer(i,:)=size(D(:,D==2),2)/TP;
end

CropTree=[CropPer, TreePer];
% 
x=[33.8226-8.56528]/9094;
XX=[8.56528:x:33.822]';


% plot(XX, CropTree(:,1)); hold on; plot(XX, CropTree(:,2)); legend('Crop', 'Tree')

for k=1:size(Aa1,2)
    F(:,k)=flip(E(:,k));
end
% dlmwrite('../Test/Ascii/rs_as1.asc', F, ' ')