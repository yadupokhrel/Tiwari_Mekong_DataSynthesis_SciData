% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Relative humidity data analysis
clear all; clc;

stations={'LA_150504_Pakse';'LA_190202_Luang_Prabang';'TH_160401_Mukdahan';'TH_199913_Mae_Suai_Dam_Site';...
    'TH_200002_Chiang_Saen';'VN_100509_Can_Tho';'VN_100605_My_Tho'};

D=[];
for i=1:7
    
    Data=dlmread(['..\Mekong_MRCS_Obs\RelativeHumidity\TXT\',char(stations(i,1)),'.txt']);
    fd=Data(Data(:,4)>-99,:);
    fdd=unique(fd(:,1));
    
    D(i,:)=size(fdd,1);
end

Mekong=dlmread('mekong_bound');
[AA, BB]=importdata('..\Mekong_MRCS_Obs\RelativeHumidity\note_RH.txt');
lonlat=AA.data;

load sequentialcolor.mat
subplot(1,2,1); scatter(lonlat(:,1), lonlat(:,2), 50); hold on
scatter(Mekong(:,1), Mekong(:,2), 1)
scatter(lonlat(:,1), lonlat(:,2), 50, D, 'filled'); colormap(sequentialcolor); colorbar; title({'Relative Humidity','(data available in years)'}); ylim([0 36])

subplot(1,2,2); bar(D); ylabel({'Relative Humidity','(data available in years)'}); xlabel('Station number')