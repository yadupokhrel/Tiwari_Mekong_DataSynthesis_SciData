% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Extract peojected GDP data
clear all; clc;

for s=1:5
    FinalData=[]; FData=[];
    for d=2030:10:2100
        ncdisp(['..\GDP\GDP_LitPopBase_025d_s\RAW\GDP',num2str(d),'_ssp',num2str(s),'.nc'])
        lon=ncread(['..\GDP\GDP_LitPopBase_025d_s\RAW\GDP',num2str(d),'_ssp',num2str(s),'.nc'], 'lon');
        lat=ncread(['..\GDP\GDP_LitPopBase_025d_s\RAW\GDP',num2str(d),'_ssp',num2str(s),'.nc'], 'lat');

        lonlon=repmat(lon', size(lat,1),1);
        latlat=repmat(lat, 1, size(lon,1));

        lonlat=[reshape(lonlon, size(lonlon,1)*size(lonlon,2),1), reshape(latlat, size(lonlon,1)*size(lonlon,2),1)];

        % lonlat=lonlat(lonlat(:,1)>90 & lonlat(:,1)<110 & lonlat(:,2)>5 & lonlat(:,2)<35,:);

        DD=ncread(['..\GDP\GDP_LitPopBase_025d_s\RAW\GDP',num2str(d),'_ssp',num2str(s),'.nc'], 'Band1');
        DD=double(DD);

        n=1; Data=[];
        for i=1:size(lon)
            for j=1:size(lat,1)

                ll=[lon(i), lat(j)];

                if ll(1,1) >93.9 && ll(1,1)<108.7 && ll(1,2)>8.6 && ll(1,2)< 33.9
                    Data(n,:)=[ll, DD(i,j)];
                    n=n+1;
                else
                    continue;
                end

            end
        end
        FData(:,(d-2020)/10)=Data(:,end);

    end

    FinalData=[Data(:,1:2), FData];

    writematrix(FinalData, ['..\GDP\GDP_LitPopBase_025d_s\Extracted\ssp',num2str(s),'_GDP.txt'], 'Delimiter','tab')

end



