# Python Script, January 20, 2023
# Amar Deep Tiwari (tiwaria6@msu.edu)
# Research Associate, Michigan State University

## Project raster to WGS 1984
## One year at once.

import arcpy

arcpy.env.workspace = r"D:\SurfaceWater\Output"

##Reproject a TIFF image with Datumn transfer
projection = arcpy.SpatialReference(4326)
for i in range(1,367): 
    inname="2016_"+('{:03}'.format(i))+".tif"
    out=r'D:\SurfaceWater\Output_proj'+'\\'+inname
    arcpy.ProjectRaster_management(inname, out, projection,"NEAREST", "#", "#", "#", "#")
