% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Streamflow data analysis
clear all; clc;

StrF=dir('..\Mekong_MRCS_Obs\Hydrology\Discharge\*.csv');


[AA, BB]=importdata('..\Mekong_MRCS_Obs\Hydrology\Discharge\xnote_discharge.txt');
lonlat=AA.data;

SlopeNSig=[];

for i=1:size(StrF,1)
    
    ff=StrF(i).name;
    fff=ff(1:end-8);
    
    Data=dlmread(['..\Mekong_MRCS_Obs\Hydrology\Discharge\TXT\',fff,'.txt']);
    Data(Data(:,end)<0,end)=NaN;
    MeanAnualFlow=NaN(99,2);
    for y=1920:2018
        MeanAnualFlow(y-1919,:)=[y, nanmean(Data(Data(:,1)==y,end),1)];
    end
   
    datain=MeanAnualFlow(MeanAnualFlow(:,end)>-1,:);
    
    plot(datain(:,1), datain(:,2))
    drawnow; pause(2)
%     [taub, tau, h, sig, Z, S, sigma, sen, n, senplot, CIlower, CIuppe, D, Dall, C3, nsigma] = ktaub(MeanAnualFlow, 0.05, 1);
    [~, ~, h, sig, ~, ~, ~, sen, ~, ~, ~, ~, ~, ~, ~, ~] = ktaub(datain, 0.05, 1);
    
    SlopeNSig(i,:)=[size(datain,1) sen h sig];
end

dlmwrite('..\Hydrology\Discharge\discharge_data_avail_trend.txt', SlopeNSig, ' ');
    
