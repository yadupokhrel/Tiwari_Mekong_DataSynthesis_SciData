% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Trends in LULC classes
clear all; clc;

ncdisp('..\RAW\1992_2015\ESACCI-LC-L4-LCCS-Map-300m-P1Y-1992-v2.0.7b.nc');
flag_values=importdata('..\Subset\nc\flag_values_both.txt');
flag_values=flag_values(:,2);
flag_meanings=importdata('..\Subset\nc\flag_meanings.txt');

Classes=NaN(29,38);
A1=ncread('..\Subset\nc\1992_2020_LMRB.nc', 'Band1');

for y=1992:2020
    
    A=A1(:,:,y-1991);
    B=reshape(A,size(A,1)*size(A,2),1);
    C=B(B>-10000,:);
    
    CC(:,y-1991)=C;
    for i=1:size(flag_values,1)
        fd=find(C(:,1)==flag_values(i,1));
        
        Classes(y-1991,i)=size(fd,1);
    end
    clear A
end

Cropland=sum(Classes(:,2:5),2);
MosaicCropland=sum(Classes(:,6),2);
TreeCover=sum(Classes(:,8:18),2);
MosaicTreeAndShrub=sum(Classes(:,19),2);
Shrubland=sum(Classes(:,21:23),2);
Grassland=sum(Classes(:,24),2);
FloodedCover=sum(Classes(:,30:32),2);
Urban=sum(Classes(:,33),2);
BareAreas=sum(Classes(:,34:36),2);
WaterBodies=sum(Classes(:,37),2);
SnowOrIce=sum(Classes(:,38),2);

AllData=[Cropland, MosaicCropland, TreeCover, MosaicTreeAndShrub, Shrubland, Grassland, ...
    FloodedCover, Urban, BareAreas, WaterBodies, SnowOrIce]*100/sum(Classes(1,:),2);
legend={'Cropland'; 'MosaicCropland'; 'TreeCover'; 'MosaicTreeAndShrub'; 'Shrubland'; 'Grassland';...
    'FloodedCover';'Urban'; 'BareAreas'; 'WaterBodies'; 'SnowOrIce'};
for j=1:11
    
    subplot(4,3,j); plot([1992:2020]', AllData(:,j), 'LineWidth', 2)
    title(char(legend(j)))
    
end