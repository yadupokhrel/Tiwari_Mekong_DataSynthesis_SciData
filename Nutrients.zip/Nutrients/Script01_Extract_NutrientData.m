% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Extract Nutrient datasets
clear all; clc;

AA=dir('../Data_MRC/CSV/TF/T*');

for i=1:size(AA,1)
    disp(i)
    f=AA(i).name;
    
    [A, B, C]=xlsread(['../Data_MRC/CSV/TF/',f]);
    
    DATES=NaN(size(B,1)-1,2);
    for j=1:size(B,1)-1
        D=B{j+1,5};
        DATES(j,:)=[str2double(D(1,1:4)), str2double(D(1,6:7))];
    end
    Data=[DATES, A(:,end)];
    
    ff=f(1,27:end-4);
    dlmwrite(['../Data_MRC/TF/',ff,'.txt'], Data, ' ')
    
    DTS(i,:)=[DATES(1,1), DATES(end,1)];
end