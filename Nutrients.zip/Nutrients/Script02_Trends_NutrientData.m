% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Trends in nutrients
clear all; clc;
files=dir('../Data_MRC/TF/*.txt');

for i=1:size(files,1)
    f1=files(i).name;
    
    A=dlmread(['../Data_MRC/TF/',f1]);
    TS(i,:)=[A(1,1:2), A(end,1:2)];
end

fd=find(TS(:,3)==2021);

for j=1:size(fd)
    
    f2=files(fd(j)).name;
    AA=dlmread(['../Data_MRC/TF/',f2]);
    
    datain=NaN(26,2);
    for y=1996:2021
        datain(y-1995,:)=[y mean(AA(AA(:,1)==y,end),1)];
    end
    [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 0);
    
    Res(j,:)=[sen, h, sig];
end

loc=dlmread('../../../Outline/Data/Nutrients/locations_nutrientdata.txt');

Lonlat_trend=[loc(fd,:), Res];

dlmwrite('../Results/lonlat_trend_sign_1996_2021_TF.txt', Lonlat_trend, ' ')