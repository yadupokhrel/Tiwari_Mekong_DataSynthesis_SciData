% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Extract population data
clear all; clc;

ncdisp('..\Population\Projected\nc\2000total.nc')
lon=ncread('..\Population\Projected\nc\2000total.nc', 'lon');
lat=ncread('..\Population\Projected\nc\2000total.nc', 'lat');

lonlon=repmat(lon', size(lat,1),1);
latlat=repmat(lat, 1, size(lon,1));

lonlat=[reshape(lonlon, size(lonlon,1)*size(lonlon,2),1), reshape(latlat, size(lonlon,1)*size(lonlon,2),1)];

% lonlat=lonlat(lonlat(:,1)>90 & lonlat(:,1)<110 & lonlat(:,2)>5 & lonlat(:,2)<35,:);

DD=ncread('..\Population\Projected\nc\2000total.nc', '2000total');
DD=double(DD);

n=1;
for i=1:size(lon)
    for j=1:size(lat,1)

        ll=[lon(i), lat(j)];

        if ll(1,1) >93.9 && ll(1,1)<108.7 && ll(1,2)>8.6 && ll(1,2)< 33.9
            Data(n,:)=[ll, DD(i,j)];
            n=n+1;
        else
            continue;
        end

    end
end

writematrix(Data, '..\Population\Projected\Extracted\Base\Base2000total.txt', 'Delimiter','tab')



