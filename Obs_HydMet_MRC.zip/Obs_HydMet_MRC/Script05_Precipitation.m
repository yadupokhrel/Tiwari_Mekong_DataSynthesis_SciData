% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% MRC precipitation data analysis
clear all; clc;

stations={'KH_110401_Chhouk';'KH_110402_Kompong_Kantout';'KH_110431_Baset';'KH_110508_Peam_Chor';'KH_120206_Treng';...
    'KH_120603_Kratie';'KH_130208_Bovel';'KH_130305_Battambang';'KH_130325_Siem_Reap_Koktatry';'KH_130406_Tbeng_(Sdau)';...
    'KH_130505_Sadan';'KH_640103_PeamKhley_dam_site';'LA_150504_Pakse';'LA_150609_Sekong';'LA_190202_Luang_Prabang';...
    'TH_150402_Yasothon';'TH_150407_Rasi_Salai';'TH_160401_Mukdahan';'TH_199913_Mae_Suai_Dam_Site';'TH_200002_Chiang_Saen'};

D=[];
for i=1:20
    
    Data=dlmread(['..\Mekong_MRCS_Obs\Meteorology\Precipitation\TXT\',char(stations(i,1)),'.txt']);
    fd=Data(Data(:,4)>-99,:);
    fdd=unique(fd(:,1));
    
    D(i,:)=size(fdd,1);
end

Mekong=dlmread('mekong_bound');
[AA, BB]=importdata('..\Mekong_MRCS_Obs\Meteorology\Precipitation\note_precipitation.txt');
lonlat=AA.data;

load sequentialcolor.mat
subplot(1,2,1); scatter(lonlat(:,1), lonlat(:,2), 50); hold on
scatter(Mekong(:,1), Mekong(:,2), 1)
scatter(lonlat(:,1), lonlat(:,2), 50, D, 'filled'); colormap(sequentialcolor); colorbar; title({'Precipitation','(data available in years)'}); caxis([0 96])

subplot(1,2,2); bar(D); ylabel({'Precipitation','(data available in years)'}); xlabel('Station number')