% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University
%% Combine data
clear all; clc;

lonlat=dlmread('lonlat_mekong_era5.txt');
TS1=dlmread('../../APHRO/codes/TS_1920_2018');
TS=TS1(TS1(:,1)>=1971 & TS1(:,1)<=2000,:);

for i=1:size(lonlat,1)
    
    P=dlmread(['../Precipitation/Extracted/data_',num2str(lonlat(i,2)),'_',num2str(lonlat(i,1))]);
    T=dlmread(['../Temperature/Extracted/data_',num2str(lonlat(i,2)),'_',num2str(lonlat(i,1))]);
    
    PT=[TS P T];
    
    PPTT=[];
    for y=1971:2000
        fd=find(PT(:,1)==y);
        
        PPTT(y-1970,:)=[sum(PT(fd,4),1), mean(PT(fd,5),1)];
    end
    
    PT3(i,:)=mean(PPTT,1);
end

dlmwrite('../Results/lonlat_mean_annual_precip_temp_ERA5.txt', [lonlat, PT3], ' ')