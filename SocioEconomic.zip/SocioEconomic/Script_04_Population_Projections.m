% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Population projection percentage change
clear all; clc;

GridsC={'Cambodia'; 'China'; 'Laos'; 'Myanmar'; 'Thailand'; 'Vietnam'};

base=readmatrix('..\Population\Projected\Extracted\Base2000total.txt');
ssp1=readmatrix('..\Population\Projected\Extracted\ssp1_POP.txt');
ssp2=readmatrix('..\Population\Projected\Extracted\ssp2_POP.txt');
ssp3=readmatrix('..\Population\Projected\Extracted\ssp3_POP.txt');
ssp4=readmatrix('..\Population\Projected\Extracted\ssp4_POP.txt');
ssp5=readmatrix('..\Population\Projected\Extracted\ssp5_POP.txt');

for i=1:size(GridsC,1)
    PercChange=[];
    for k=1:5
        
        ssp=readmatrix(['..\Population\Projected\Extracted\ssp',num2str(k),'_POP.txt']);
        
        lonlat=readmatrix(['Grids\',char(GridsC(i)),'Grids.txt']);
        
        Data=NaN(size(lonlat,1), 11);
        for j=1:size(lonlat,1)
            
            fd=find(ssp(:,1)==lonlat(j,1) & ssp(:,2)==lonlat(j,2));
            
            Data(j,:)=[base(fd,end), ssp(fd,3:end)];
            
        end
        
        MeanP=mean(Data,1);
        PercChange(:,k)=(MeanP(1, 2:end)-MeanP(1,1))*100/MeanP(1,1);
    end
    
    dlmwrite(['..\Results\PopulationChange_',char(GridsC(i)),'.txt'], [[2010:10:2100]', PercChange], ' ')
    subplot(3,2,i); plot([2010:10:2100]', PercChange); title([char(GridsC(i))]); legend('ssp1', 'ssp2', 'ssp3', 'ssp4', 'ssp5')
end


