# Python Script, January 20, 2023
# Amar Deep Tiwari (tiwaria6@msu.edu)
# Research Associate, Michigan State University

## Mosaic To New Raster from 2001-2016
## One year at once.

##==================================
##Mosaic To New Raster
##Usage: MosaicToNewRaster_management inputs;inputs... output_location raster_dataset_name_with_extension 
##                                    {coordinate_system_for_the_raster} 8_BIT_UNSIGNED | 1_BIT | 2_BIT | 4_BIT 
##                                    | 8_BIT_SIGNED | 16_BIT_UNSIGNED | 16_BIT_SIGNED | 32_BIT_FLOAT | 32_BIT_UNSIGNED 
##                                    | 32_BIT_SIGNED | | 64_BIT {cellsize} number_of_bands {LAST | FIRST | BLEND  | MEAN 
##                                    | MINIMUM | MAXIMUM} {FIRST | REJECT | LAST | MATCH}                               

import os, numpy as np, arcpy
from arcpy import env
from arcpy.sa import *
env.workspace = r'D:\SurfaceWater\Pekel\RAW'

for i in range(1,13):    
    rasters=arcpy.ListRasters('2003_'+('{:02}'.format(i))+'*'+'.tif')
    outname="2016_"+('{:02}'.format(i))+".tif"
    arcpy.MosaicToNewRaster_management(rasters, "D:\SurfaceWater\Pekel\Output", outname, "","8_BIT_UNSIGNED", "", "1", "","")
