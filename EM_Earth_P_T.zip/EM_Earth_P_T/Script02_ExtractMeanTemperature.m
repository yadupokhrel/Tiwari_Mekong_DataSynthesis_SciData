% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Extract Temperature datasets
clear all; clc;

models={'001.nc';'002.nc';'003.nc';'004.nc';'005.nc';'006.nc';'007.nc';'008.nc';'009.nc';'010.nc';'011.nc';'012.nc';...
    '013.nc';'014.nc';'015.nc';'016.nc';'017.nc';'018.nc';'019.nc';'020.nc';'021.nc';'022.nc';'023.nc';'024.nc';'025.nc'};

for m=1:size(models,1)
    ncdisp(['..\Temperature\1950_2019\',char(models(m)),'\EM_Earth_probabilistic_daily_tmean_Asia_sub_1950_2019_',char(models(m))]);
    
    A=ncread(['..\Temperature\1950_2019\',char(models(m)),'\EM_Earth_probabilistic_daily_tmean_Asia_sub_1950_2019_',char(models(m))], 'tmean');
    
    lon=ncread(['..\Temperature\1950_2019\',char(models(m)),'\EM_Earth_probabilistic_daily_tmean_Asia_sub_1950_2019_',char(models(m))], 'lon');
    lat=ncread(['..\Temperature\1950_2019\',char(models(m)),'\EM_Earth_probabilistic_daily_tmean_Asia_sub_1950_2019_',char(models(m))], 'lat');
    
    lonlat=dlmread('corresp_lonlat_mekong_10km');
    
    n=1; C=[];
    for i=1:size(lon,1)
        for j=1:size(lat,1)
            
            disp([i j])
            ll=[lon(i), lat(j)];
            fd=find(lonlat(:,1)==ll(1,1) & lonlat(:,2)==ll(1,2));
            
            if isempty(fd)
                continue;
            else
                B=squeeze(A(i,j,:));
                C(:,n)=B;
                n=n+1;
            end
        end
    end
    

    dlmwrite(['..\Temperature\Timeseries\1950_2019\data_',char(models(m)),'.txt'], C, ' ')
end