% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%%
clear all; clc;
% Data=dlmread('../Results/GLEAM_ET_v3.6a_Daily_1980_2021.txt');
ReadTab=dlmread('C:\Users\tiwaria6\OneDrive - Michigan State University\2022_Tiwari_Amar\Manuscript_Ideas\Paper1_DataPaper\Submission1_SciData\Data\ET\ET\GLEAM_ET_v3.6a_Daily_1980_2021.txt');
lonlat=ReadTab(1:2,4:end)';
TS=ReadTab(3:end,1:3);
Data=ReadTab(3:end,4:end);

for i=1:size(lonlat,1)
    disp(i)
    D1=[TS, Data(:,i)];
    
    D2=[]; n=1;
    for y=1980:2021
        for m=1:12
            fd=find(D1(:,1)==y & D1(:,2)==m);
            D2(n,:)=[y m sum(D1(fd,end),1)];
            n=n+1;
        end
    end
    
    D3=reshape(D2(:,end),12, size(D2,1)/12);
    
    DSp=sum(D3(3:5,:),1)';      % Spring
    DSu=sum(D3(6:8,:),1)';      % Summer
    DAu=sum(D3(9:11,:),1)';     % Autumn
    DWi=sum(D3([12 1 2],:),1)'; % Winter
    
    
    SeasonalET(i,:)=[mean(DSp,1), mean(DSu,1), mean(DAu,1), mean(DWi,1)];
    
    A_ET(i,:)=sum(D3,1)';
end

AnnualET=nanmean(A_ET,1)';
datain=[[1980:2021]', AnnualET];
[taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 1);
% scatter(lonlat(:,1), lonlat(:,2), 100, SeasonalET(:,1), 's', 'filled')

dlmwrite('../Results/lonlat_ET_Sp_Su_Au_Wi_36a.txt', [lonlat, SeasonalET], ' ')
dlmwrite('../Results/year_mean_annual_ET_36a.txt', [[1980:2021]', AnnualET], ' ')



