% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University
%%
clear all; clc;

ncdisp('../Data/v6.0_GHG.nc')

lon=ncread('../Data/v6.0_GHG.nc', 'lon');
lat=ncread('../Data/v6.0_GHG.nc', 'lat');


ch4=ncread('../Data/v6.0_GHG.nc', 'emi_ch4');
co2=ncread('../Data/v6.0_GHG.nc', 'emi_co2');
co2_2=ncread('../Data/v6.0_GHG.nc', 'emi_co2_2');
n2o=ncread('../Data/v6.0_GHG.nc', 'emi_n2o');

lonlat=dlmread('./lonlat_mekong_10km');

for i=1:size(lon,1)
    for j=1:size(lat,1)
        
        ll=[lon(i), lat(j)];
        
        %         fd=find(lonlat(:,1)==ll(1,1) & lonlat(:,2)==ll(1,2));
        
        yearconv=24*60*60*[365;365;366;365;365;365;366;365;365;365;366;365;365;365;366;365;365;365;366;365;365;365;366;365;365;365;...
            366;365;365;365;366;365;365;365;366;365;365;365;366;365;365;365;366;365;365;365;366;365;365];
        kmconv=11.1*1000*11.1*1000;
        tonconv=1/1000;
        
        m=yearconv*kmconv*tonconv;
        A=[squeeze(ch4(i,j,:)).*m,squeeze(co2(i,j,:)).*m, squeeze(co2_2(i,j,:)).*m,squeeze(n2o(i,j,:)).*m];
        B=sum(A,2);
        
        dlmwrite(['../Data/Gridded/data_',num2str(ll(1,2)),'_',num2str(ll(1,1))], B, ' ')

    end
end


for i=1:size(lonlat,1)
    
    AA=dlmread(['../Data/Gridded/data_',num2str(lonlat(i,2)),'_',num2str(lonlat(i,1))]);
    
    BB(:,i)=AA;
end

DataAll=[[[NaN; NaN], lonlat']; [1970:2018]', BB];

dlmwrite('GHG_AllData.txt', DataAll, ' ')