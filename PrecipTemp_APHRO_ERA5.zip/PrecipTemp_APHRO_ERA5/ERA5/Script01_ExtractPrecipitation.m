% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University
%% Extract ERA5 precipitation data
clear all; clc;

ncdisp('../Precipitation/RAW/1971_1980.nc')

lat=ncread('../Precipitation/RAW/1971_1980.nc', 'latitude');
lon=ncread('../Precipitation/RAW/1971_1980.nc', 'longitude');

lonlat=dlmread('lonlat_mekong_era5.txt');

precip=ncread('../Precipitation/RAW/1971_2000.nc', 'tp');

for i=1:size(lon,1)
    for j=1:size(lat,1)
        
        fd=find(round(lonlat(:,1),2)==round(lon(i,1),2) & round(lonlat(i,2),2)==round(lat(j,1),2));
        
%         if isempty(fd)
%             continue;
%         else
            A=squeeze(precip(i,j,:))*1000;
            B=[A(2:end); A(1,1)];
            C=reshape(B, 24, size(B,1)/24);
            
            D=sum(C,1)';
            
            dlmwrite(['../Precipitation/Extracted/data_',num2str(lat(j,1)),'_',num2str(lon(i,1))], round(D,2), ' ')
%         end
    end
end
