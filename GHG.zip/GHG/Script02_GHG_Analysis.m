% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%%
clear all; clc;

Data=dlmread('../Data/GHG_AllData.txt');


for i=1:size(Data,2)-1
    
    datain=Data(3:end,[1,i+1]);
    alpha=0.05; wantplot=0;
    
    [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, alpha, wantplot);
    
    Res(i,:)=[sen, h, sig];
end

lonlat=Data(1:2,2:end)';

DD=[lonlat, Res];

dlmwrite('../Results/lonlat_GHG_trends.txt', DD, ' ')
dlmwrite('../Results/Year_Mean_GHG.txt', [Data(3:end,1), mean(Data(3:end,2:end),2)], ' ')

PP=[Data(3:end,1), mean(Data(3:end,2:end),2)];
[taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(PP, alpha, 1);