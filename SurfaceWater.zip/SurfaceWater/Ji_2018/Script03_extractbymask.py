# Python Script, January 20, 2023
# Amar Deep Tiwari (tiwaria6@msu.edu)
# Research Associate, Michigan State University

## Extract by mask for Mekong

import os, numpy as np, arcpy
from arcpy import env
from arcpy.sa import *

arcpy.CheckOutExtension("Spatial")
arcpy.env.pyramid = "NONE"

arcpy.env.workspace = r'D:\SurfaceWater\Shapefile'
shapename= arcpy.ListFeatureClasses('*.shp') 
arcpy.env.workspace = r'D:\SurfaceWater\Output_proj'
fl_name1= arcpy.ListRasters('*.tif')

for j in shapename:
    for i in fl_name1:
        print(i)
        inraster=r'D:\SurfaceWater\Output_proj'+'\\'+i
        shp=r'D:\SurfaceWater\Shapefile'+'\\'+j
        outraster=r'D:\SurfaceWater\Output_subset'+'\\'+i
        out = ExtractByMask(inraster, shp)
        out.save(outraster)
