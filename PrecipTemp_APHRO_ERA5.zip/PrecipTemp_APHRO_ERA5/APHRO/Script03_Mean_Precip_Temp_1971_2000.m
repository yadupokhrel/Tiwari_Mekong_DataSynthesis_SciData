% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University
%% Combine all data
LOLA=dlmread('lonlat_mekong_25km.txt');
TS=dlmread('TS_1920_2018');

TS_P=TS(TS(:,1)>=1951 & TS(:,1)<=2007,:);
TS_T=TS(TS(:,1)>=1961 & TS(:,1)<=2015,:);

PT3=NaN(size(LOLA,1),2);
for ii=1:size(LOLA,1)
    
    disp(ii)
    BB=[];
    
    P=dlmread(['../APHRO_V1101_MA_025deg/Extracted/1951_2007/data_',num2str(LOLA(ii,2)),'_',num2str(LOLA(ii,1))]);
    
    PP=[TS_P, P];
    T=dlmread(['../APHRO_V1808_TEMP_MA_025deg/Extracted/1961_2015/data_',num2str(LOLA(ii,2)),'_',num2str(LOLA(ii,1))]);
    TT=[TS_T, T];
    
    PT=[PP(PP(:,1)>=1971 & PP(:,1)<=2000,:), TT(TT(:,1)>=1971 & TT(:,1)<=2000,end)];
    
    P3=[]; T3=[];
    for y=1971:2000
        
        fd=find(PT(:,1)==y);
        
        P3(y-1970,:)=sum(PT(fd,4));
        T3(y-1970,:)=mean(PT(fd,5));
    end
    
    PT3(ii,:)=[mean(P3,1), mean(T3,1)];
end

scatter(LOLA(:,1), LOLA(:,2), 20, PT3(:,1),'filled')
dlmwrite('../Results/lonlat_mean_annual_precip_temp_APHRO.txt', [lonlat, PT3], ' ')