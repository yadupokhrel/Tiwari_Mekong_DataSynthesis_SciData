% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Change in cropland and tree cover
clear all; clc;

ncdisp('..\RAW\1992_2015\ESACCI-LC-L4-LCCS-Map-300m-P1Y-1992-v2.0.7b.nc');
flag_values=importdata('..\Subset\nc\flag_values.txt');
flag_meanings=importdata('..\Subset\nc\flag_meanings.txt');

% CC=NaN(8900503,29);

lon=ncread('..\RAW\1992_2015\ESACCI-LC-L4-LCCS-Map-300m-P1Y-1992-v2.0.7b.nc', 'lon');
lat=ncread('..\RAW\1992_2015\ESACCI-LC-L4-LCCS-Map-300m-P1Y-1992-v2.0.7b.nc', 'lat');

lonlon=repmat(lon', size(lat,1),1);
latlat=repmat(lat, 1, size(lon,1));


lonlat=[reshape(lonlon, size(lon,1)*size(lat,1),1), reshape(latlat, size(lon,1)*size(lat,1),1)];
for y=[1992, 2000]%:2020
    %     ncdisp(['..\Subset\nc\',num2str(y),'.nc'])
    A=ncread(['..\Subset\nc\',num2str(y),'.nc'], 'Band1');
    
    B=reshape(A,size(A,1)*size(A,2),1);
    
    
    C=B(B>-10000,:);
    D=C;
    for i=1:size(C,1)
        if C(i,1)<9.5 || C(i,1)>90.5
            D(i,1)=0;
        elseif C(i,1)>30.5 && C(i,1)<50.5
            D(i,1)=0;
        elseif C(i,1)>9.5 && C(i,1)<30.5
            D(i,1)=1;
        elseif C(i,1)>50.5 && C(i,1)<90.5
            D(i,1)=4;
            
        end
    end
    
    DD(:,y-1991)=D;
    
end

% Diff=DD(:,2)-DD(:,1);