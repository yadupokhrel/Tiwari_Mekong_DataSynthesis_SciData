% Matlab Script, January 20, 2023
% Amar Deep Tiwari (tiwaria6@msu.edu)
% Research Associate, Michigan State University

%% Annual Precip

clear all; clc;
TS1=dlmread('TS_1950_2020.txt');
TS=TS1(TS1(:,1)>=1950 & TS1(:,1)<=2019,:);
lonlat=dlmread('corresp_lonlat_mekong_10km');
models={'001.nc';'002.nc';'003.nc';'004.nc';'005.nc';'006.nc';'007.nc';'008.nc';'009.nc';'010.nc';'011.nc';'012.nc';...
    '013.nc';'014.nc';'015.nc';'016.nc';'017.nc';'018.nc';'019.nc';'020.nc';'021.nc';'022.nc';'023.nc';'024.nc';'025.nc'};


parfor m=1:25
    
    disp(m)
    AT=dlmread(['D:\MSU_Work\EM_Earth\Precipitation\Timeseris\All\data_',char(models(m)),'.txt']);
%     AT1=AT(10958:end,:);
    AT1=AT(1:end,:);
    AT2(:,:,m)=AT1;
end
AT3=mean(AT2,3);
AT4=[TS, mean(AT3,2)];


for y=1950:2019
    fd=find(AT4(:,1)==y);
    
    AT5(y-1949,1:2)=[y sum(AT4(fd,end),1)];
end

dlmwrite('annual_precip_1950_2019.txt', AT5, ' ')

%% Annual Temp

clear all; clc;
lonlat=dlmread('corresp_lonlat_mekong_10km');
TS1=dlmread('TS_1950_2020.txt');
TS=TS1(TS1(:,1)>=1980 & TS1(:,1)<=2019,:);
models={'001.nc';'002.nc';'003.nc';'004.nc';'005.nc';'006.nc';'007.nc';'008.nc';'009.nc';'010.nc';'011.nc';'012.nc';...
    '013.nc';'014.nc';'015.nc';'016.nc';'017.nc';'018.nc';'019.nc';'020.nc';'021.nc';'022.nc';'023.nc';'024.nc';'025.nc'};

parfor m=1:25
    
    disp(m)
    AT=dlmread(['..\Temperature\Timeseries\All\data_',char(models(m)),'.txt']);
    
    AT1=AT(10958:end,:);
    AT2(:,:,m)=AT1;
end

AT3=mean(AT2,3);
AT4=[TS, mean(AT3,2)];


for y=1980:2019
    fd=find(AT4(:,1)==y);
    
    AT5(y-1979,1:2)=[y mean(AT4(fd,end),1)];
end

dlmwrite('annual_temp_1980_2019.txt', AT5, ' ')

